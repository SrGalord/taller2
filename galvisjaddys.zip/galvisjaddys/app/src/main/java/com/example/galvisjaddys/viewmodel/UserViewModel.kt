package com.example.galvisjaddys.viewmodel

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.example.galvisjaddys.model.User
import com.example.galvisjaddys.repository.UserRepository

class UserViewModel : ViewModel() {

    private val repository = UserRepository()

    // LiveData privado mutable
    private val _users = MutableLiveData<List<User>>()
    val users: LiveData<List<User>> = _users

    private val _selectedUser = MutableLiveData<User?>()
    val selectedUser: LiveData<User?> = _selectedUser

    private val _isLoading = MutableLiveData<Boolean>()
    val isLoading: LiveData<Boolean> = _isLoading

    init {
        loadUsers()
    }

    fun loadUsers() {
        _isLoading.value = true

        android.os.Handler(android.os.Looper.getMainLooper()).postDelayed({
            _users.value = repository.getAllUsers()
            _isLoading.value = false
        }, 500)
    }

    fun selectUser(user: User) {
        _selectedUser.value = user
    }

    fun addUser(name: String, email: String, age: Int) {
        val newId = (repository.getAllUsers().maxOfOrNull { it.id } ?: 0) + 1
        val newUser = User(newId, name, email, age)
        repository.addUser(newUser)
        loadUsers()
    }

    fun deleteUser(userId: Int) {
        repository.deleteUser(userId)
        loadUsers()
    }
}